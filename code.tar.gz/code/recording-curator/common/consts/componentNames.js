/*
 * Created by nassi on 01/11/15.
 */

var Components = {
    MAIN: 'Main',
    ROLLING_INDEX: 'Rolling-index',
    INDEX_MANAGER: 'Index-Manger',
    FILES_MANAGER: 'Files-Manager',
    CLIENT_PROXY: 'Client-Proxy'
};

module.exports = Components;
