/**
 * Created by nassi on 03/01/16.
 * The main entry point of the application
 * which starts the bootstrap module
 */

const bootstrap = require('./bootstrap');

bootstrap.init().catch((error) => {
    console.error(error);
    process.exit(1);
});

