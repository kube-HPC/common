/*
 * Created by nassi on 17/11/16.
 */

'use strict';

var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var mockery = require('mockery');
var bootstrap = require('../bootstrap');
var indices = require('../lib/index/index-consts.js');
var clientProxy, rollingIndex;

describe('Vod-Service', function () {
    // Enable mockery at the start of your test suite
    before(function (done) {
        mockery.enable({
            useCleanCache: false,
            warnOnReplace: true,
            warnOnUnregistered: false
        });

        mockery.registerSubstitute('elastic-client', process.cwd() + '/tests/mocks/elastic-client');

        bootstrap.init().then(function () {
            clientProxy = require('../lib/index/client-proxy');
            rollingIndex = require('../lib/index/rolling-index');
            done();
        }).catch((error) => {
            process.exit(1);
        });
    });
    after(function () {
        mockery.deregisterAll();
        mockery.disable(); // Disable Mockery after tests are completed
    });

    describe('Index', function () {
        describe('createIndex', function () {
            it('should return type error index must be provided', function (done) {
                rollingIndex.createIndex(null, (error) => {
                    expect(error.message).to.equals('index must be provided');
                    done();
                });
            });
            it('should return type error index must be from type Index', function (done) {
                rollingIndex.createIndex({index: 100}, (error) => {
                    expect(error.message).to.equals('index must be from type Index');
                    done();
                });
            });
            it('should return success', function (done) {
                rollingIndex.createIndex({index: indices.metadata}, (error) => {
                    expect(error).to.be.undefined;
                    done();
                });
            });
        });
        describe('updateAliases', function () {
            it('should return type error index must be provided', function (done) {
                rollingIndex.updateAliases(null, (error) => {
                    expect(error.message).to.equals('index must be provided');
                    done();
                });
            });
            it('should return type error index must be from type Index', function (done) {
                rollingIndex.updateAliases({index: 100}, (error) => {
                    expect(error.message).to.equals('index must be from type Index');
                    done();
                });
            });
        });
        describe('deleteOldIndexes', function () {
            it('should return type error index must be provided', function (done) {
                rollingIndex.deleteOldIndices(null, (error) => {
                    expect(error.message).to.equals('index must be provided');
                    done();
                });
            });
            it('should return type error index must be from type Index', function (done) {
                rollingIndex.deleteOldIndices({index: 100}, (error) => {
                    expect(error.message).to.equals('index must be from type Index');
                    done();
                });
            });
            it('should return success', function (done) {
                rollingIndex.deleteOldIndices({index: indices.metadata}, (error) => {
                    expect(error).to.be.undefined;
                    done();
                });
            });
        });
    });
});

