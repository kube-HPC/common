-------------------------------------------------
# RECORDING-CURATOR
-------------------------------------------------

This service is responsible for

## Rolling index
  - create indices
  - update aliases
  - delete old indexes

## File Cleaning
  - remove old recordings
