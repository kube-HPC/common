/*
 * Created by nassi on 02/01/17.
 */

process.env.NODE_PATH = __dirname;
require('module').Module._initPaths();

const configIt = require('config-it');
const Logger = require('logger');
const VerbosityPlugin = require('logger').VerbosityPlugin;
const errorHandler = require('common').errorHandler;
const componentName = require('./common/consts/componentNames');
let log;

const modules = [
    'lib/index/rolling-index',
    'lib/recordings/files-manager'
];

class Bootstrap {
    async init() {
        try {
            const {config, logger} = await configIt.readConfigs();
            this._handleErrors();

            log = new Logger(config.serviceName, logger);
            log.plugins.use(new VerbosityPlugin(config.redis));
            log.info('running application in ' + configIt.env() + ' environment', {component: componentName.MAIN});

            await Promise.all(modules.map(m => require(m).init(config)));
            return config;
        }
        catch (error) {
            this._onInitFailed(new Error(`unable to start application. ${error.message}`));
        }
    }

    _handleErrors() {
        errorHandler.on('exit', (code) => {
            log.info('exit' + (code ? ' code ' + code : ''), {component: componentName.MAIN});
        });
        errorHandler.on('SIGINT', () => {
            log.info('SIGINT', {component: componentName.MAIN});
            process.exit(1);
        });
        errorHandler.on('SIGTERM', () => {
            log.info('SIGTERM', {component: componentName.MAIN});
            process.exit(1);
        });
        errorHandler.on('unhandledRejection', (error) => {
            log.error('unhandledRejection: ' + error.message, {component: componentName.MAIN}, error);
        });
        errorHandler.on('uncaughtException', (error) => {
            log.error('uncaughtException: ' + error.message, {component: componentName.MAIN}, error);
            process.exit(1);
        });
    }
}

module.exports = new Bootstrap();
