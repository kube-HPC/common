var localIP = require('common').getLocalIp();
var config = module.exports = {};
var elasticSecured = process.env.ELASTICSEARCH_SERVICE_SECURED === 'true' || process.env.ELASTICSEARCH_SERVICE_SECURED === true;
var useSentinel = process.env.REDIS_SENTINEL_SERVICE_HOST ? true : false;

config.serviceName = 'recording-curator';

config.redis = {
    host: useSentinel ? process.env.REDIS_SENTINEL_SERVICE_HOST : process.env.REDIS_SERVICE_HOST || 'localhost',
    port: useSentinel ? process.env.REDIS_SENTINEL_SERVICE_PORT : process.env.REDIS_SERVICE_PORT || 6379,
    sentinel: useSentinel
};

config.elasticsearch = {
    client: {
        protocol: elasticSecured ? 'https' : 'http',
        host: process.env.ELASTICSEARCH_SERVICE_HOST || localIP,
        port: process.env.ELASTICSEARCH_SERVICE_PORT || 9200,
        path: process.env.ELASTICSEARCH_SERVICE_PATH || '',
    },
    livenessCheckInterval: 15000
};

config.rollingIndex = {
    dateFormat: 'YYYY.MM.DD',
    hoursToSaveWriteIndicesAlias: 24,
    hoursToSaveReadIndices: 48,
    cron: '0 1 * * *',
    // cron: '*/10 * * * * *',
    maxRetries: 10
};

config.recordings = {
    recordingUrl: process.env.RECORDING_PATH || process.env.HOME + '/nfs/vod',
    dateFormat: 'YYYY.MM.DD',
    hoursToSave: 48,
    cron: '0 1 * * *'
    // cron: '*/10 * * * * *'
};
