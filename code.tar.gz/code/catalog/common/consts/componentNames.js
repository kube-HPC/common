/*
 * Created by nassi on 01/11/15.
 */

var Components = {
    MAIN: 'Main',
    REST_API: 'Rest-API',
    REST_API_CATALOG: 'Rest-API-Catalog',
    SOCKET_API: 'Socket-API',
    SOCKET_API_CATALOG: 'Socket-API-Catalog',
    REDIS_API_CATALOG: 'Redis-API-Catalog',
    XML_PROVIDER_SOCKET: 'Sds-Provider-Socket',
    CATALOG_REPORTING: 'Catalog-Reporting',
    CATALOG_LISTENER: 'Catalog-Listener',
    CATALOG: 'Catalog',
    ONLINE_SENSORS_PROVIDER: 'Online-Sensors-Provider',
    EMTZAIM_PROVIDER: 'Emtzaim-Provider',
    STANDALONE_PROVIDER: 'StandAlone-Provider',
    SUPERVISOR_PROVIDER: 'Supervisor-Provider',
    WORKER_PROVIDER: 'Worker-Provider',
    RECORDING_WORKER_PROVIDER: 'Recording-Worker-Provider',
    XML_PROVIDER: 'Sds-Provider',
    CATALOG_UPDATER: 'Catalog-Updater'
};

module.exports = Components;
