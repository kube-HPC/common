/*
 * Created by nassi on 02/01/17.
 */

process.env.NODE_PATH = __dirname;
require('module').Module._initPaths();

const configIt = require('config-it');
const Logger = require('logger');
const VerbosityPlugin = require('logger').VerbosityPlugin;
const errorHandler = require('common').errorHandler;
const monitor = require('redis-utils').Monitor;
const Keepalive = require('keepalive-service').Client;
const uuid = require('uuid/v4');
const componentName = require('common/consts/componentNames');
let log;

const modules = [
    'lib/catalog',
    'api/redis-api/catalog',
    'lib/reporting/catalog',
    'lib/pub-sub/config',
    'lib/providers/authProvider',
    'lib/providers/supervisorProvider',
    'lib/providers/sdsProvider',
    'lib/providers/workerProvider',
    'lib/providers/recordingWorkerProvider',
    'lib/providers/emtzaimProvider',
    'lib/providers/onlineStatusProvider',
    'lib/providers/standAloneProvider'
];

class Bootstrap {
    async init() {
        try {
            const {config, logger} = await configIt.readConfigs();
            this._handleErrors();
            this._keepalive(config);

            log = new Logger(config.serviceName, logger);
            log.plugins.use(new VerbosityPlugin(config.redis));
            log.info('running application in ' + configIt.env() + ' environment', {component: componentName.MAIN});

            monitor.on('ready', (data) => {
                log.info((data.message).green, {component: componentName.MAIN});
            });
            monitor.on('close', (data) => {
                log.error(data.error.message, {component: componentName.MAIN});
            });
            await monitor.check(config.redis);
            const appServer = require('api/rest-api/app-server');
            const socketServer = require('api/socket-api/socket-server');
            const dataRest = await appServer.init(config);
            const dataSocket = await socketServer.init(config, dataRest.server);
            log.info(dataRest.message, {component: componentName.REST_API});
            log.info(dataSocket.message, {component: componentName.SOCKET_API});

            await Promise.all(modules.map(m => require(m).init(config)));
            return config;
        }
        catch (error) {
            this._onInitFailed(new Error(`unable to start application. ${error.message}`));
        }
    }

    _onInitFailed(error) {
        if (log) {
            log.error(error.message, {component: componentName.MAIN}, error);
            log.error(error);
        }
        else {
            console.error(error.message);
            console.error(error);
        }
        process.exit(1);
    }

    _keepalive(config) {

        const KEEPALIVE_EVERY_MS = 1000;
        const keepaliveKeyPrefix = 'catalog-keepalive';
        const keepalive_client = new Keepalive({
            host: config.redis.host,
            port: config.redis.port,
            sentinel: config.redis.sentinel,
            interval: KEEPALIVE_EVERY_MS,
            timeout: config.keepAlive.keepAliveTimeoutMs,
            reconnectTimeout: config.keepAlive.noCommunicationTimeout,
            prefix: keepaliveKeyPrefix,
            uuid: uuid()
        });

        keepalive_client.on('timeout', () => {
            // redis connection timeout. Kill process
            log.error('keepalive communication error: ' + config.serviceName + ' service. ', {component: componentName.MAIN});
            process.exit(1);
        });

        keepalive_client.start();
    }

    _handleErrors() {
        errorHandler.on('exit', (code) => {
            log.info('exit' + (code ? ' code ' + code : ''), {component: componentName.MAIN});
        });
        errorHandler.on('SIGINT', () => {
            log.info('SIGINT', {component: componentName.MAIN});
            process.exit(1);
        });
        errorHandler.on('SIGTERM', () => {
            log.info('SIGTERM', {component: componentName.MAIN});
            process.exit(1);
        });
        errorHandler.on('unhandledRejection', (error) => {
            log.error('unhandledRejection: ' + error.message, {component: componentName.MAIN}, error);
        });
        errorHandler.on('uncaughtException', (error) => {
            log.error('uncaughtException: ' + error.message, {component: componentName.MAIN}, error);
            process.exit(1);
        });
    }
}

module.exports = new Bootstrap();

