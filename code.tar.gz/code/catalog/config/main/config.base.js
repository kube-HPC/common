var localIP = require('common').getLocalIp();
var config = module.exports = {};

config.serviceName = 'catalog';

var baseSecured = process.env.BASE_URL_SECURED === 'true' || process.env.BASE_URL_SECURED === true;
var sdsSecured = process.env.SDS_SERVICE_SECURED === 'true' || process.env.SDS_SERVICE_SECURED === true;
var emtzaimSecured = process.env.EMTZAIM_SECURED === 'true' || process.env.EMTZAIM_SECURED === true;
var useSentinel = process.env.REDIS_SENTINEL_SERVICE_HOST ? true : false;

config.redis = {
    host: useSentinel ? process.env.REDIS_SENTINEL_SERVICE_HOST : process.env.REDIS_SERVICE_HOST || 'localhost',
    port: useSentinel ? process.env.REDIS_SENTINEL_SERVICE_PORT : process.env.REDIS_SERVICE_PORT || 6379,
    sentinel: useSentinel
};

config.rest = {
    port: process.env.CATALOG_REST_PORT || 9092
};

config.repository = {
    prefix: 'vod:'
};

config.swaggerPath = {
    protocol: baseSecured ? 'https' : 'http',
    host: process.env.BASE_URL_HOST || localIP,
    port: process.env.BASE_URL_PORT || config.rest.port,
    path: process.env.BASE_URL_PATH || ''
};

config.catalogService = {
    socket: {
        protocol: baseSecured ? 'wss' : 'ws',
        host: process.env.BASE_URL_HOST || localIP,
        port: process.env.BASE_URL_PORT || config.rest.port,
        path: process.env.BASE_URL_PATH || '/catalog'
    }
};

config.sdsService = {
    socket: {
        enable: true,
        protocol: sdsSecured ? 'wss' : 'ws',
        host: process.env.SDS_SERVICE_HOST || 'localhost',
        port: process.env.SDS_SERVICE_PORT || 3388,
        path: '/socket'
    }
};

config.emtzaimService = {
    socket: {
        enable: true,
        protocol: emtzaimSecured ? 'wss' : 'ws',
        host: process.env.EMTZAIM_HOST || 'localhost', // 101.1.157.77
        port: process.env.EMTZAIM_PORT || 8081 // 8081, 43130
    }
};

config.onlineService = {
    requestInterval: 30000,
    timeForSwitchingToOffline: 40000
};

config.keepAlive = {
    noCommunicationTimeout: 100000,
    keepAliveTimeoutMs: 20000
};

config.secureMode = false;
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // Enable Self-Signed cartificate
config.securitySettings = {
    keyFilePath: './node_modules/express-wrapper/key.pem',
    certificateFilePath: './node_modules/express-wrapper/cert.pem'
};
