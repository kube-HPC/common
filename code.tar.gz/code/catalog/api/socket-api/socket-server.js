/**
 * Created by nassi on 15/10/15.
 * This module initialize the socket app server
 */

'use strict';

const io = require('socket.io');
const catalogSocket = require('api/socket-api/catalog');
const urlHelper = require('common').UrlHelper;

module.exports.init = startSocketApp;

function startSocketApp(options, server) {
    return new Promise((resolve, reject) => {
        const socketIO = io.listen(server);
        const path = options.catalogService.socket.path;
        const ns = path.substring(path.lastIndexOf('/'));
        const nsp = socketIO.of(ns);
        catalogSocket.run(nsp);
        return resolve({
            message: `socket service exposed on ${urlHelper.concatUri(options.catalogService.socket)}`
        });
    });
}

