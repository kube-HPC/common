/*
 * Created by nassi on 18/10/15.
 *
 * socket.io API:
 * sensor-list
 * add-sensor
 * remove-sensor
 * update-sensor-data
 * update-sensor-status
 */

'use strict';

const eventsSpec = require('catalog-api').EventsSpec;
const socketSpec = require('catalog-api').SocketSpec;
const catalog = require('lib/catalog');
const outputClientsAdapter = require('lib/adapters/output-clients-adapter');
const Logger = require('logger');
const log = Logger.GetLogFromContanier();
const componentName = require('common/consts/componentNames');

class CatalogSocketIO {

    run(socketIO) {
        if (this._isInit) {
            log.warning('already initialize', { component: componentName.SOCKET_API_CATALOG });
            return;
        }
        this._isInit = true;
        this._initSocketIO(socketIO);
        this._initCatalogEvents(socketIO);
    }

    _initSocketIO(socketIO) {
        socketIO.on('connection', (socket) => {
            // send the list of live video sources on client connection.
            this.sendList(socket);

            // send the list of live video sources on client request.
            socket.on(socketSpec.GetList, () => {
                this.sendList(socket);
            });

            socket.on('disconnect', () => {
                // nothing to do here
            });
        });
    }

    _initCatalogEvents(socketIO) {
        for (const t in eventsSpec) {
            const event = eventsSpec[t];
            catalog.on(event, (data) => {
                const topic = socketSpec[t];
                if (topic) {
                    socketIO.emit(topic, outputClientsAdapter.toClientVideoData(data));
                }
            });
        }
    }

    sendList(socket) {
        catalog.list().then((data) => {
            socket.emit(socketSpec.GetList, outputClientsAdapter.toClientVideoList(data));
        }).catch((error) => {
            log.error(error, { component: componentName.SOCKET_API_CATALOG });
        });
    }
}

var socketIO = new CatalogSocketIO();
module.exports = socketIO;
