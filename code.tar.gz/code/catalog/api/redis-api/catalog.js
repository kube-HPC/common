/*
 * Created by nassi on  29/06/16.
 */

'use strict';

var pubsubSpec = require('catalog-api').PubSubSpec;
var eventsSpec = require('catalog-api').EventsSpec;
var PubSubAdapter = require('pub-sub-adapter');
var catalog = require('lib/catalog');
var Logger = require('logger');
var log = Logger.GetLogFromContanier();
var componentName = require('common/consts/componentNames');

class CatalogRedis {

    constructor() {
    }

    init(options) {
        return new Promise((resolve, reject) => {
            if (this._isInit) {
                return reject(new Error('already initialize'));
            }
            this._isInit = true;
            this._pubSubAdapter = new PubSubAdapter(options.redis);
            this._pubSubAdapter.on('error', (error) => {
                log.error(error, { component: componentName.REDIS_API_CATALOG });
            });
            this._initCatalogEvents();
            this._initCatalogRequests();
            return resolve();
        });
    }

    // this method expose only push notifications and get operations (read-only api),
    // the set operations is available only inside the providers.

    _initCatalogEvents() {
        for (const t in eventsSpec) {
            const event = eventsSpec[t];
            catalog.on(event, (data) => {
                const topic = pubsubSpec[t];
                if (topic) {
                    this._pubSubAdapter.publish(topic, JSON.stringify(data));
                }
            });
        }
    }

    _initCatalogRequests() {
        this._pubSubAdapter.requestReplySubscribe(pubsubSpec.Get, (message, publishFunction) => {
            catalog.get(message).then((data) => {
                publishFunction({ data });
            }).catch((error) => {
                publishFunction({ error: error.message });
            });
        });

        this._pubSubAdapter.requestReplySubscribe(pubsubSpec.GetList, (message, publishFunction) => {
            catalog.list(message).then((data) => {
                publishFunction({ data });
            }).catch((error) => {
                publishFunction({ error: error.message });
            });
        });
    }
}

var catalogRedis = new CatalogRedis();
module.exports = catalogRedis;
