/*
 * Created by yehiyam on 9/27/16.
 */

const setup = require('./setup');
const chai = require('chai');
const expect = chai.expect;
const mockery = require('mockery');
const RedisFactory = require('redis-utils').Factory;
const VideoItem = require('catalog-api').VideoItem;
const VideoStatus = require('catalog-api').VideoStatus;
const pubsubAdapter = require('pub-sub-adapter');
var pubsubSpec = require('catalog-api').PubSubSpec;
var config, redis;
var catalog = require('../lib/catalog');

describe('recorder worker provider', function () {
    before(function (done) {
        config = global.RMS.config;
        redis = new pubsubAdapter(config.redis);
        redisClient = RedisFactory.getClient(config.redis);
        redisClient.flushdb(() => {
            done();
        });
    });

    describe('recorder provider requst reply', function () {
        before(function (done) {
            var videoItem = new VideoItem('Test_Video_remove_job');
            catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoData) {
                done();
            });
        });
        describe('Update recording status through provider', function () {
            it('should fail with invalid video', function (done) {
                redis.requestReply(pubsubSpec.UpdateRecordingStatus + '-' + 'recording-worker-provider',
                    {vid: 'Test_Video_remove_job', status: VideoStatus.RECORDING}).then(ret => {
                    catalog.get({vid: 'Test_Video_remove_job'}).then(videoItem => {
                        expect(videoItem.recording.status.code).to.equal(VideoStatus.RECORDING);
                        done();
                    });
                });
            });
        });
    });
});

