/*
 * Created by yehiyam on 9/27/16.
 */

const setup = require('./setup');
const chai = require('chai');
const expect = chai.expect;
const mockery = require('mockery');
const request = require('request');
const RedisFactory = require('redis-utils').Factory;
const VideoStatus = require('catalog-api').VideoStatus;
const mockSensors = require('./mockSdsSensor');
var VideoItem = require('catalog-api').VideoItem;
var config, sdsProvider;
var catalog = require('../lib/catalog');

describe('SDS provider', function () {
    before(function (done) {
        config = global.RMS.config;
        sdsProvider = require('../lib/providers/sdsProvider.js');
        redisClient = RedisFactory.getClient(config.redis);
        redisClient.flushdb(() => {
            done();
        });
    });

    describe('SDS provider request reply', function () {
        describe('Create item through provider', function () {
            it('should create sensor', function (done) {
                const video = sdsProvider._createVideoItem(mockSensors.sensor1);
                const videoItem = new VideoItem(video);
                expect(videoItem.vid).to.equal('sensorId*' + mockSensors.sensor1.SensorId + '*');
                expect(videoItem.status.code).to.equal(VideoStatus.CLOSED);
                expect(videoItem.recording.status.code).to.equal(VideoStatus.CLOSED);
                done();
            });
        });
    });
});

