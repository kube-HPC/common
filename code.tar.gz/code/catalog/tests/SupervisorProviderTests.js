/*
 * Created by yehiyam on 9/27/16.
 */

const setup = require('./setup');
const chai = require('chai');
const expect = chai.expect;
const mockery = require('mockery');
const request = require('request');
const RedisFactory = require('redis-utils').Factory;
const VideoItem = require('catalog-api').VideoItem;
const VideoStatus = require('catalog-api').VideoStatus;
const pubsubAdapter = require('pub-sub-adapter');
const pubsubSpec = require('catalog-api').PubSubSpec;
var config, redis;
const catalog = require('../lib/catalog');

describe('Supervisor provider', function () {
    before(function (done) {
        config = global.RMS.config;
        redis = new pubsubAdapter(config.redis);
        redisClient = RedisFactory.getClient(config.redis);
        redisClient.flushdb(() => {
            done();
        });
    });

    describe('Supervisor provider request reply', function () {
        describe('Create item through provider', function () {
            it('should create video', function (done) {
                const videoData = new VideoItem({ vid: 'SA_Test_Video' });
                redis.requestReply(pubsubSpec.Add + '-' + 'supervisor-provider', {
                    vid: videoData.vid,
                    videoData
                }).then(() => {
                    catalog.get({ vid: 'SA_Test_Video' }).then(addedItem => {
                        expect(addedItem.vid).to.equal(videoData.vid);
                        expect(addedItem.recording.status.code).to.equal(VideoStatus.CLOSED);
                        expect(addedItem.status.code).to.equal(VideoStatus.CLOSED);
                        done();
                    });
                });
            });
        });
        describe('update status through provider', function () {
            it('should update the status to streaming', function (done) {
                const videoData = new VideoItem({ vid: 'SA_Test_Video_2' });
                catalog.add({ vid: videoData.vid, videoData }).then(() => {
                    redis.requestReply(pubsubSpec.UpdateStatus + '-' + 'supervisor-provider', {
                        vid: videoData.vid,
                        status: { code: VideoStatus.STREAMING }
                    }).then(() => {
                        catalog.get({ vid: 'SA_Test_Video_2' }).then(item => {
                            expect(item.status.code).to.equal(VideoStatus.STREAMING);
                            done();
                        });
                    });
                });
            });
        });
    });
});

