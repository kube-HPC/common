/*
 * Created by nassi on 24/02/16.
 */

const setup = require('./setup');
var chai = require('chai');
const expect = chai.expect;
const sinon = require('sinon');
const mockery = require('mockery');
const request = require('request');
const socketClient = require('socket.io-client');
const urlHelper = require('common').UrlHelper;
const RedisFactory = require('redis-utils').Factory;
const VideoItem = require('catalog-api').VideoItem;
const VideoStatus = require('catalog-api').VideoStatus;
const WorkerErrors = {WEBRTC: 'WEBRTC'};
var config;
const catalog = require('../lib/catalog');
const catalogUrl = 'http://localhost:9092';

describe('Catalog', function () {
    before(function (done) {
        config = global.RMS.config;
        redisClient = RedisFactory.getClient(config.redis);
        redisClient.flushdb(() => {
            done();
        });
    });

    describe('REST API', function () {
        describe('/catalog/list', function () {
            it('should return empty array', function (done) {
                request({
                    method: 'GET',
                    uri: catalogUrl + '/list',
                    json: true

                }, function (error, response, body) {
                    expect(body).to.be.instanceof(Array);
                    expect(response.statusCode).equal(200);
                    done();
                });
            });
            it('should return one entry', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                videoItem.status.error = 'TestError';
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoData) {
                    request({
                        method: 'GET',
                        uri: catalogUrl + '/list',
                        json: true

                    }, function (error, response, body) {
                        expect(body).to.be.instanceof(Array);
                        expect(body.length).to.equal(1);
                        expect(body[0].status.code).to.equal(VideoStatus.CLOSED);
                        expect(body[0].status.error).to.equal('TestError');
                        expect(body[0].labels[0]).to.equal(VideoStatus.CLOSED);
                        expect(response.statusCode).equal(200);
                        done();
                    });
                });
            });
            it('should return one entry', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoData) {
                    request({
                        method: 'GET',
                        uri: catalogUrl + '/listraw',
                        json: true

                    }, function (error, response, body) {
                        expect(body).to.be.instanceof(Array);
                        expect(body.length).to.equal(1);
                        expect(body[0].status.code).to.equal(VideoStatus.CLOSED);
                        expect(response.statusCode).equal(200);
                        done();
                    });
                });
            });
        });
    });
    xdescribe('SOCKET API', function () {
        let url;
        // catalogSocketIO.on('connect', function (ev, data) {
        //     $rootScope.$broadcast('socketioLoaded', socketio);
        // });
        // catalogSocketIO.on('disconnect', function (ev, data) {
        //
        // });
        // catalogSocketIO.on('sensor-list', function (data) {
        //
        // });
        // catalogSocketIO.on('remove-sensor', function (data) {
        // });
        // catalogSocketIO.on('update-sensor-labels', function (data) {
        // });
        // catalogSocketIO.on('update-sensor-status', function (data) {
        // });
        // catalogSocketIO.on('update-sensor-recording-labels', function (data) {
        // });
        // catalogSocketIO.on('update-sensor-recording-status', function (data) {
        // });

        before(function () {
            url = urlHelper.concatUri(config.catalogService.socket);

        });

        describe('add', function () {
            it('should add the item and return it as response', function (done) {
                const catalogSocketIO = socketClient.connect(url);
                catalogSocketIO.on('add-sensor', function (data) {
                    expect(data.vid).to.equal(videoItem.vid);
                    done();
                });
                const videoItem = new VideoItem('Test_Video_add_socket');
                catalog.add({vid: videoItem.vid, videoData: videoItem});

            });
        });
        describe('set', function () {
            it('should set an item', function (done) {
                const catalogSocketIO = socketClient.connect(url);
                const videoItem = new VideoItem('Test_Video_set_socket');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function () {
                    catalog.set({vid: videoItem.vid, videoData: videoItem})
                });
                catalogSocketIO.on('update-sensor-data', function (data) {
                    expect(data.vid).to.equal(videoItem.vid);
                    done();
                });
            });
        });
        describe('delete', function () {
            it('should return error if non exists key is supplied', function (done) {
                const catalogSocketIO = socketClient.connect(url);
                const videoItem = new VideoItem('Test_Video_delete');
                catalog.delete({vid: videoItem.vid}).catch(function (error) {
                    expect(error.message).to.equal(`failed to delete video: ${videoItem.vid}, error: cannot find key: vod:${videoItem.vid}`);
                    done();
                });
            });
            it('should return error if key is not supplied', function (done) {
                catalog.delete({vid: null}).catch(function (error) {
                    expect(error.message).to.equal('failed to delete video: null, error: parameter missing: key');
                    done();
                });
            });
        });
        describe('get', function () {
            it('should return error if non exists key is supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_get');
                catalog.get({vid: videoItem.vid, videoData: videoItem}).catch(function (error) {
                    expect(error.message).to.equal(`failed to get video: ${videoItem.vid}, error: cannot find key: vod:${videoItem.vid}`);
                    done();
                });
            });
            it('should return error if key is not supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_get_No_Key_Video');
                catalog.get({vid: null, videoData: videoItem}).catch(function (error) {
                    expect(error.message).to.equal('failed to get video: null, error: parameter missing: key');
                    done();
                });
            });
        });
        describe('update status', function () {
            it('should return error if non exists key is supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_get');
                catalog.updateStatus({vid: videoItem.vid, videoData: videoItem}).catch(function (error) {
                    expect(error.message).to.equal(`failed to update status video: ${videoItem.vid}, error: cannot find key: vod:${videoItem.vid}`);
                    done();
                });
            });
            it('should return error if key is not supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_get_No_Key_Video');
                catalog.updateStatus({vid: null, videoData: videoItem}).catch(function (error) {
                    expect(error.message).to.equal(`failed to update status video: null, error: parameter missing: key`);
                    done();
                });
            });
            it('should update the status to streaming', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateStatus({
                        vid: videoItem.vid,
                        status: {code: VideoStatus.STREAMING}
                    }).then(function (videoData) {
                        expect(videoData.status.code).to.equal(VideoStatus.STREAMING);
                        expect(videoData.status.error).to.be.undefined;
                        done();
                    });
                });
            });
            it('should update the status to closed with just string', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateStatus({vid: videoItem.vid, status: VideoStatus.CLOSING}).then(function (videoData) {
                        expect(videoData.status.code).to.equal(VideoStatus.CLOSING);
                        expect(videoData.status.error).to.be.undefined;

                        done();
                    });
                });
            });

            it('should update the status to error with reason', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateStatus({
                        vid: videoItem.vid, status: {
                            code: VideoStatus.ERROR,
                            error: WorkerErrors.WEBRTC
                        }
                    }).then(function (videoData) {
                        expect(videoData.status.code).to.equal(VideoStatus.ERROR);
                        expect(videoData.status.error).to.equal(WorkerErrors.WEBRTC);
                        done();
                    });
                });
            });
        });
        describe('update recorder status', function () {
            it('should return error if non exists key is supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_get');
                catalog.updateRecordingStatus({
                    vid: videoItem.vid,
                    status: {code: VideoStatus.CLOSED}
                }).catch(function (error) {
                    expect(error.message).to.equal(`failed to update recording status video: ${videoItem.vid}, error: cannot find key: vod:${videoItem.vid}`);
                    done();
                });
            });
            it('should return error if key is not supplied', function (done) {
                catalog.updateRecordingStatus({vid: null, status: {code: VideoStatus.CLOSED}}).catch(function (error) {
                    expect(error.message).to.equal(`failed to update recording status video: null, error: parameter missing: key`);
                    done();
                });
            });
            it('should update the status to streaming', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateRecordingStatus({
                        vid: videoItem.vid,
                        status: {code: VideoStatus.RECORDING}
                    }).then(function (videoData) {
                        expect(videoData.recording.status.code).to.equal(VideoStatus.RECORDING);
                        expect(videoData.recording.status.error).to.be.undefined;
                        done();
                    });
                });
            });
            it('should update the status to closing with just string', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateRecordingStatus({
                        vid: videoItem.vid,
                        status: VideoStatus.CLOSING
                    }).then(function (videoData) {
                        expect(videoData.recording.status.code).to.equal(VideoStatus.CLOSING);
                        expect(videoData.recording.status.error).to.be.undefined;
                        done();
                    });
                });
            });

            it('should update the status to error with reason', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateRecordingStatus({
                        vid: videoItem.vid, status: {
                            code: VideoStatus.ERROR,
                            error: WorkerErrors.WEBRTC
                        }
                    }).then(function (videoData) {
                        expect(videoData.recording.status.code).to.equal(VideoStatus.ERROR);
                        expect(videoData.recording.status.error).to.equal(WorkerErrors.WEBRTC);
                        done();
                    });
                });
            });
        });
    });
    describe('Actions', function () {
        describe('add', function () {
            it('should add the item and return it as response', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoData) {
                    expect(videoData.vid).to.equal(videoItem.vid);
                    done();
                });
            });
            it('should return error if key is not supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_add_no_key');
                catalog.add({vid: null, videoData: videoItem}).catch(function (error) {
                    expect(error.message).to.equal('failed to add video: null, error: parameter missing: key');
                    done();
                });
            });
        });
        describe('set', function () {
            it('should return error if non exists key is supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_set_No_Exists_Key');
                catalog.set({vid: videoItem.vid, videoData: videoItem}).catch(function (error) {
                    expect(error.message).to.equal(`failed to set video: ${videoItem.vid}, error: cannot find key: vod:${videoItem.vid}`);
                    done();
                });
            });
            it('should return error if invalid key is supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_set_No_Key_Supplied');
                catalog.set({vid: null, videoData: videoItem}).catch(function (error) {
                    expect(error.message).to.equal('failed to set video: null, error: parameter missing: key');
                    done();
                });
            });
            it('should set an item', function (done) {
                const videoItem = new VideoItem('Test_Video_set');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoData) {
                    catalog.set({vid: videoItem.vid, videoData: videoItem}).then(function (videoData) {
                        expect(videoData.current.vid).to.equal(videoItem.vid);
                        done();
                    });
                });
            });
            it('should set a partial item', function (done) {
                const videoItem = new VideoItem('Test_Video_set');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoData) {
                    catalog.updateStatus({vid: videoItem.vid, status: {code: VideoStatus.INIT}}).then(() => {
                        const newData = {
                            clientData: {
                                metadataUrl: 'oneUrlToGo'
                            },
                            adapterData: {}
                        };
                        catalog.set({vid: videoItem.vid, videoData: newData}).then(function (videoData) {
                            catalog.get({vid: videoItem.vid}).then(item => {
                                expect(item.vid).to.equal(videoItem.vid);
                                expect(item.status.code).to.equal(VideoStatus.INIT);
                                expect(item.clientData.metadataUrl).to.equal('oneUrlToGo');
                                done();
                            });
                        });
                    });
                });
            });

            it('should ignore recording status when setting item', function (done) {
                const videoItem = new VideoItem('Test_Video_set');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoData) {
                    catalog.updateStatus({vid: videoItem.vid, status: {code: VideoStatus.INIT}}).then(() => {
                        const newData = {
                            clientData: {
                                metadataUrl: 'oneUrlToGo'
                            },
                            adapterData: {},
                            recording: {
                                status: {code: VideoStatus.CLOSED}
                            },

                        };
                        catalog.set({vid: videoItem.vid, videoData: newData}).then(function (videoData) {
                            catalog.get({vid: videoItem.vid}).then(item => {
                                expect(item.vid).to.equal(videoItem.vid);
                                expect(item.status.code).to.equal(VideoStatus.INIT);
                                expect(item.clientData.metadataUrl).to.equal('oneUrlToGo');
                                done();
                            });
                        });
                    });
                });
            });
        });
        describe('delete', function () {
            it('should return error if non exists key is supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_delete');
                catalog.delete({vid: videoItem.vid}).catch(function (error) {
                    expect(error.message).to.equal(`failed to delete video: ${videoItem.vid}, error: cannot find key: vod:${videoItem.vid}`);
                    done();
                });
            });
            it('should return error if key is not supplied', function (done) {
                catalog.delete({vid: null}).catch(function (error) {
                    expect(error.message).to.equal('failed to delete video: null, error: parameter missing: key');
                    done();
                });
            });
        });
        describe('get', function () {
            it('should return error if non exists key is supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_get');
                catalog.get({vid: videoItem.vid, videoData: videoItem}).catch(function (error) {
                    expect(error.message).to.equal(`failed to get video: ${videoItem.vid}, error: cannot find key: vod:${videoItem.vid}`);
                    done();
                });
            });
            it('should return error if key is not supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_get_No_Key_Video');
                catalog.get({vid: null, videoData: videoItem}).catch(function (error) {
                    expect(error.message).to.equal('failed to get video: null, error: parameter missing: key');
                    done();
                });
            });
        });
        describe('update status', function () {
            it('should return error if non exists key is supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_get');
                catalog.updateStatus({vid: videoItem.vid, videoData: videoItem}).catch(function (error) {
                    expect(error.message).to.equal(`failed to update status video: ${videoItem.vid}, error: cannot find key: vod:${videoItem.vid}`);
                    done();
                });
            });
            it('should return error if key is not supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_get_No_Key_Video');
                catalog.updateStatus({vid: null, videoData: videoItem}).catch(function (error) {
                    expect(error.message).to.equal(`failed to update status video: null, error: parameter missing: key`);
                    done();
                });
            });
            it('should update the status to streaming', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateStatus({
                        vid: videoItem.vid,
                        status: {code: VideoStatus.STREAMING}
                    }).then(function (videoData) {
                        expect(videoData.status.code).to.equal(VideoStatus.STREAMING);
                        expect(videoData.status.error).to.be.undefined;
                        done();
                    });
                });
            });
            it('should update the status to closed with just string', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateStatus({vid: videoItem.vid, status: VideoStatus.CLOSING}).then(function (videoData) {
                        expect(videoData.status.code).to.equal(VideoStatus.CLOSING);
                        expect(videoData.status.error).to.be.undefined;

                        done();
                    });
                });
            });

            it('should update the status to error with reason', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateStatus({
                        vid: videoItem.vid, status: {
                            code: VideoStatus.ERROR,
                            error: WorkerErrors.WEBRTC
                        }
                    }).then(function (videoData) {
                        expect(videoData.status.code).to.equal(VideoStatus.ERROR);
                        expect(videoData.status.error).to.equal(WorkerErrors.WEBRTC);
                        done();
                    });
                });
            });
        });
        describe('update recorder status', function () {
            it('should return error if non exists key is supplied', function (done) {
                const videoItem = new VideoItem('Test_Video_get');
                catalog.updateRecordingStatus({
                    vid: videoItem.vid,
                    status: {code: VideoStatus.CLOSED}
                }).catch(function (error) {
                    expect(error.message).to.equal(`failed to update recording status video: ${videoItem.vid}, error: cannot find key: vod:${videoItem.vid}`);
                    done();
                });
            });
            it('should return error if key is not supplied', function (done) {
                catalog.updateRecordingStatus({vid: null, status: {code: VideoStatus.CLOSED}}).catch(function (error) {
                    expect(error.message).to.equal(`failed to update recording status video: null, error: parameter missing: key`);
                    done();
                });
            });
            it('should update the status to streaming', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateRecordingStatus({
                        vid: videoItem.vid,
                        status: {code: VideoStatus.RECORDING}
                    }).then(function (videoData) {
                        expect(videoData.recording.status.code).to.equal(VideoStatus.RECORDING);
                        expect(videoData.recording.status.error).to.be.undefined;
                        done();
                    });
                });
            });
            it('should update the status to closing with just string', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateRecordingStatus({
                        vid: videoItem.vid,
                        status: VideoStatus.CLOSING
                    }).then(function (videoData) {
                        expect(videoData.recording.status.code).to.equal(VideoStatus.CLOSING);
                        expect(videoData.recording.status.error).to.be.undefined;
                        done();
                    });
                });
            });

            it('should update the status to error with reason', function (done) {
                const videoItem = new VideoItem('Test_Video_add');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoDataAdded) {
                    catalog.updateRecordingStatus({
                        vid: videoItem.vid, status: {
                            code: VideoStatus.ERROR,
                            error: WorkerErrors.WEBRTC
                        }
                    }).then(function (videoData) {
                        expect(videoData.recording.status.code).to.equal(VideoStatus.ERROR);
                        expect(videoData.recording.status.error).to.equal(WorkerErrors.WEBRTC);
                        done();
                    });
                });
            });
        });
    });
});

