
process.env.NODE_PATH = process.cwd();
require('module').Module._initPaths();

const RedisFactory = require('redis-utils').Factory;
const bootstrap = require('../bootstrap');
let redisClient;

before(function (done) {
    bootstrap.init().then(function (config) {
        global.RMS = {};
        global.RMS.config = config;
        redisClient = RedisFactory.getClient(config.redis);
        redisClient.flushdb(() => {
            done();
        });
    }).catch((error) => {
        process.exit(1);
    });
});
after(function (done) {
    redisClient.flushdb(() => {
        done();
    });
});

