/*
 * Created by yehiyam on 9/27/16.
 */

const setup = require('./setup');
var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var mockery = require('mockery');
var request = require('request');
const RedisFactory = require('redis-utils').Factory;
var VideoItem = require('catalog-api').VideoItem;
var VideoStatus = require('catalog-api').VideoStatus;
var catalog = require('../lib/catalog');
var config;

describe('catalog updater', function () {
    describe('call remove job', function () {
        const spy = sinon.spy(catalog, 'removeJob');
        before(function (done) {
            config = global.RMS.config;
            redisClient = RedisFactory.getClient(config.redis);
            redisClient.flushdb(() => {
                var videoItem = new VideoItem('Test_Video_remove_job');
                catalog.add({vid: videoItem.vid, videoData: videoItem}).then(function (videoData) {
                    done();
                });
            });

        });
        describe('called when streamer status changes', function () {
            it('should be called when streamer status changed to closed', function (done) {
                spy.reset();
                catalog.updateStatus({
                    vid: 'Test_Video_remove_job',
                    status: VideoStatus.CLOSED
                }).then(function (videoData) {
                    expect(spy.callCount).to.equal(1);
                    expect(spy.args[0][0].jobType).to.equal('streaming');
                    done();
                });
            });

            it('should not be called when streamer status changed to streaming', function (done) {
                spy.reset();
                catalog.updateStatus({
                    vid: 'Test_Video_remove_job',
                    status: VideoStatus.STREAMING
                }).then(function (videoData) {
                    expect(spy.callCount).to.equal(0);
                    done();
                });
            });
        });
        describe('called when recorder status changes', function () {
            it('should be called when recorder status changed to closed', function (done) {
                spy.reset();
                catalog.updateRecordingStatus({
                    vid: 'Test_Video_remove_job',
                    status: VideoStatus.CLOSED
                }).then(function (videoData) {
                    expect(spy.args[0][0].jobType).to.equal('recording');
                    done();
                });
            });

            it('should not be called when recorder status changed to streaming', function (done) {
                spy.reset();
                catalog.updateRecordingStatus({
                    vid: 'Test_Video_remove_job',
                    status: VideoStatus.STREAMING
                }).then(function (videoData) {
                    expect(spy.callCount).to.equal(0);
                    done();
                });
            });
        });
    });
});

