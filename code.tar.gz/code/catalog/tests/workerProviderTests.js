/**
 * Created by yehiyam on 9/27/16.
 */

const setup = require('./setup');
const chai = require('chai');
const expect = chai.expect;
const sinon = require('sinon');
const mockery = require('mockery');
const request = require('request');
const RedisFactory = require('redis-utils').Factory;
const VideoItem = require('catalog-api').VideoItem;
const VideoStatus = require('catalog-api').VideoStatus;
const pubsubAdapter = require('pub-sub-adapter');
var pubsubSpec = require('catalog-api').PubSubSpec;
var config, redis;
var catalog = require('../lib/catalog');

describe('worker provider', function () {
    before(function (done) {
        config = global.RMS.config;
        redis = new pubsubAdapter(config.redis);
        redisClient = RedisFactory.getClient(config.redis);
        redisClient.flushdb(() => {
            done();
        });
    });

    describe('provider requst reply', function () {
        before(function (done) {
            var videoItem = new VideoItem('Test_Video_1');
            catalog.add({ vid: videoItem.vid, videoData: videoItem }).then(function (videoData) {
                done();
            });
        });
        describe('Update status through provider', function () {
            it('should update the status to init', function (done) {
                redis.requestReply(pubsubSpec.UpdateStatus + '-' + 'streaming-worker-provider',
                    { vid: 'Test_Video_1', status: VideoStatus.INIT }).then(ret => {
                        catalog.get({ vid: 'Test_Video_1' }).then(videoItem => {
                            expect(videoItem.status.code).to.equal(VideoStatus.INIT);
                            expect(videoItem.clientData.metadataUrl).to.be.undefined;
                            done();
                        });
                    });
            });

            it('should update the status to streaming', function (done) {
                redis.requestReply(pubsubSpec.UpdateStatus + '-' + 'streaming-worker-provider', {
                    vid: 'Test_Video_1',
                    status: { code: VideoStatus.STREAMING },
                }).then(ret => {
                    catalog.get({ vid: 'Test_Video_1' }).then(videoItem => {
                        expect(videoItem.status.code).to.equal(VideoStatus.STREAMING);
                        done();
                    });
                });
            });
        });
    });
});

