/**
 * Created by yehiyam on 9/27/16.
 */
'use strict';
module.exports = {
    sensor1: {
        'SensorId': 'testSenser1',
        'IP': '101.150.4.72',
        'Port': 10001,
        'VideoStandard': 'bb',
        'DisplayName': 'Display Name 1',
        'SensorType': 'Type 1',
        'PlaneType': null,
        'SensorName': null,
        'Protocol': 'tcp',
        'Labels': {
            'RunningCommands': {
                'AutoPlay': false,
                'AutoRecord': false
            },
            'EnvironmentRestrictions': {
                'host': 'lab5',
                'videostandard': 'bb'
            }
        },
        'VideoArguments': [
            '-f',
            'rawvideo',
            '-pix_fmt',
            'gray',
            '-r',
            '25',
            '-s',
            '512x640'
        ]
    }
};
