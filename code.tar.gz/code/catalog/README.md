-------------------------------------------------
# Catalog
-------------------------------------------------

The server exposes *REST API* and *Socket API*

-------------------------------------------------
# Catalog REST API
 -------------------------------------------------
## Listing video sources
  - GET:  ``` /catalog/list ```
  OR
  - GET:  ``` /catalog/getListOfOnlineSensors ```
### Example

 ```js   
require('express').get('/catalog/list')
```

-------------------------------------------------
## Catalog Socket.io API:
-------------------------------------------------

- topic:  ``` 'get-list-of-online-sensors' ```
event: ``` on('sensor-list') ```

- other events:
    ``` on('update-sensor-status', videoData) ```

-------------------------------------------------
## Catalog
-------------------------------------------------

The *catalog* manages the data for the video sources.
It is a library that exposes a singleton with API as depicted below.
Note: all functions (except for dispose) return a *Promise*.

-------------------------------------------------
## Data structure
-------------------------------------------------

structure of the object stored in the catalog
*Note:* the catalog is only aware of the properties: *vid* and *labels*, 
all other properties are opaque to the catalog and will be save as is.

```js
videoData {
     'vid': string,
     'title': string,
     'labels': { 'metadata': bool, 'online': bool, 'mitpasim': bool, 'status': 'closed' / 'streaming' / 'inactive' / 'error' },
     'adapterData': { // the adapterData object is opaque to the catalog (the fields below are presented here as an example)
         'externalId': string,
         'videoStandard': string,
         'videoUrl': string,
         'metadataUrl': string
     }
}
```

``` 'online' ```: no worker but may be active after a user requests
``` 'status' ```: 'closed' / 'streaming' / 'inactive' / 'error'
``` 'mitpassim' ```: allocated for mitpassim

-------------------------------------------------
#### add videoData:
the videoData argument is created in the catalog
-------------------------------------------------

```js
add(vid, videoData);
``` 
-------------------------------------------------------------------------
#### set videoData:
the videoData argument is merged with the existing record in the catalog
-------------------------------------------------------------------------
```js

set(vid, videoData);
```

----------------------------------------------------------
#### update labels:
The labels argument is defined above (data structure)
It is possible to pass a part of the labels structure 
and the catalog will merge it with the existing labels
----------------------------------------------------------

```js 
updateLabels(vid, labels);
```
-------------------------------------------
#### delete video data
delete a video record from the catalog
-------------------------------------------

```js
delete(vid);
```
-------------------------------------------
#### get video data by vid
-------------------------------------------

```js
get(vid);
```
-------------------------------------------
#### get keys (vids) for all video sources
-------------------------------------------
```js

keys();
```

-------------------------------------------
#### get data for all video sources
-------------------------------------------

```js
getVideoList();
```
-------------------------------------------
#### clear the catalog
remove all records from the catalog.
-------------------------------------------
```js
clear();
```
-------------------------------------------
#### cleanup
e.g., disconnect the underline repository.
-------------------------------------------

```js
dispose();
```

----------------------------------------------
#### event registery - register for catalog events
----------------------------------------------

```js
on('event-name', function (videoData) {
	// your code goes here...
});
```

#### The exposed events are:
1. ``` 'add-sensor' ```
2. ``` 'remove-sensor' ```
3. ``` 'update-sensor-data' ```
4. ``` 'update-sensor-status' ```
