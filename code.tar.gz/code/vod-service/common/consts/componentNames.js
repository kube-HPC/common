/*
 * Created by nassi on 01/11/15.
 */

var Components = {
    MAIN: 'Main',
    REST_API: 'REST-API',
    REST_API_SEARCH: 'REST-API-SEARCH',
    SOCKET_API: 'SOCKET-API',
    METADATA_SEARCH: 'Metadata-Search',
    CUE_POINT_SEARCH: 'Cuepoints-Search'
};

module.exports = Components;
