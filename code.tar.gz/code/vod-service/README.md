-------------------------------------------------
# VOD-SERVICE
-------------------------------------------------

-------------------------------------------------
# REST API
 -------------------------------------------------

By default, the service listens on port 9093 (configurable).
*POST* body should be *json*.

## Adding a video source
  - POST: ``` /vod/search ```
  - POST: ``` /vod/search/advanced ```
  - POST: ``` /vod/list ```
  
### Example

See [api/rest-api/swagger.json](swagger.json) for details.