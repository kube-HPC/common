/**
 * Created by nassi on 05/04/17.
 * The main entry point of the application
 * which starts the bootstrap module
 */

const bootstrap = require('./bootstrap');

bootstrap.init().catch((error) => {
    console.error(error);
    process.exit(1);
});


