/*
 * Created by nassi on 18/10/15.
 *
 */

'use strict';

const metaData = require('lib/search/metadata-search');
const Logger = require('logger');
var log;
const componentName = require('common/consts/componentNames');
const LIST_TOPIC = 'offline-sensor-list';

class CatalogSocketIO {

    run(socketIO) {
        return new Promise((resolve, reject) => {
            if (this._isInit) {
                return reject(new Error('already initialize'));
            }
            log = Logger.GetLogFromContanier();
            this._isInit = true;
            this._initSocketIO(socketIO);
            return resolve();
        });
    }

    _initSocketIO(socketIO) {
        socketIO.on('connection', (socket) => {
            // send the list of live video sources on client connection.
            this.sendList(socket);

            // send the offline videos on client request.
            socket.on(LIST_TOPIC, () => {
                this.sendList(socket);
            });

            socket.on('disconnect', () => {
                // nothing to do here
            });
        });
    }

    sendList(socket) {
        metaData.getVideoList().then((response) => {
            socket.emit(LIST_TOPIC, response);
        }).catch((error) => {
            log.error(error, {component: componentName.SOCKET_API_CATALOG});
        });
    }
}

module.exports = new CatalogSocketIO();
