/**
 * Created by nassi on 15/10/15.
 */

const io = require('socket.io');
const catalogSocket = require('api/socket-api/vod');
const urlHelper = require('common').UrlHelper;

/**
 * This module initialize the socket app server
 */
class SocketServer {

    async init(options, server) {
        const socketIO = io.listen(server);
        const path = options.offlineService.socket.path;
        const ns = path.substring(path.lastIndexOf('/'));
        const nsp = socketIO.of(ns);
        await catalogSocket.run(nsp);
        return {
            message: `socket service exposed on ${urlHelper.concatUri(options.offlineService.socket)}`
        };

    }
}

module.exports = new SocketServer();
