/*
 * Created by nassi on 01/07/16.
 *
 * This module is a simple handler for /vod route
 * The module exports the routes function.
 *
 *  REST API:
 *  GET: '/'
 *  POST: '/vod'
 */

'use strict';

const http = require('http');
const express = require('express');
const metaData = require('lib/search/metadata-search');
const ValidationError = require('lib/errors/ValidationError');
const logger = require('logger');
const log = logger.GetLogFromContanier();
const componentName = require('common/consts/componentNames');
const INTERNAL_ERROR = 500;

var routes = function () {
    const router = express.Router();

    router.get('/', (req, res) => {
        res.json({message: 'vod api'});
    });

    router.post('/search', (req, res, next) => {
        metaData.search(req.body).then((response) => {
            res.json(response);
        }).catch((error) => {
            _handleNext(error, next);
        });
    });

    router.post('/search/segments', (req, res, next) => {
        metaData.getSegmentsByRecordID(req.body).then((response) => {
            res.json(response);
        }).catch((error) => {
            _handleNext(error, next);
        });
    });

    router.post('/search/advanced', (req, res, next) => {
        metaData.searchAdvanced(req.body).then((response) => {
            res.json(response);
        }).catch((error) => {
            _handleNext(error, next);
        });
    });

    router.post('/list', (req, res, next) => {
        metaData.getVideoList(req.body).then((response) => {
            res.json(response);
        }).catch((error) => {
            _handleNext(error, next);
        });
    });

    router.post('/search/record', (req, res, next) => {
        metaData.getRecordID(req.body).then((response) => {
            res.json(response);
        }).catch((error) => {
            _handleNext(error, next);
        });
    });

    function _handleNext(error, next) {
        log.error(error.message, {component: componentName.REST_API_SEARCH});
        if (!error.status) {
            error.status = INTERNAL_ERROR;
            error.message = http.STATUS_CODES[INTERNAL_ERROR];
        }
        return next(error);
    }

    return router;
};

module.exports = routes;
