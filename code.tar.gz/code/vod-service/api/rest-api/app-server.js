/*
 * Created by nassi on 15/10/15.
 * This module initialize the express app server
 * including settings, middleware and routes.
 */

const RestServer = require('rest-server');
const rest = new RestServer();
const routerVOD = require('./routes/vod');
const swagger = require('./swagger.json');
const versionHelper = require('common').VersionHelper;
const Logger = require('logger');
var log;
const componentName = require('common/consts/componentNames');

class AppServer {

    init(options) {
        log = Logger.GetLogFromContanier();
        return new Promise((resolve, reject) => {
            const routes = [
                {route: '/vod', router: routerVOD.call(routerVOD, options)}
            ];

            rest.on('error', (res) => {
                log.error('Error response, status=' + res.status + ', message=' + res.error.message, {component: componentName.REST_API});
            });

            swagger.host = options.swaggerPath.host + ':' + options.swaggerPath.port;
            swagger.basePath = options.swaggerPath.path;

            const opt = {
                swagger: swagger,
                name: options.serviceName,
                routes,
                port: options.rest.port,
            };
            rest.start(opt).then((data) => {
                versionHelper(options.serviceName, data.app, log);
                resolve({
                    message: data.message,
                    server: data.server
                });
            }).catch((error) => {
                reject(error);
            });
        });
    }
}

module.exports = new AppServer();
