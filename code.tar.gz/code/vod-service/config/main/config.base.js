var localIP = require('common').getLocalIp();
var config = module.exports = {};

var baseSecured = process.env.BASE_URL_SECURED === 'true' || process.env.BASE_URL_SECURED === true;
var elasticSecured = process.env.ELASTICSEARCH_SERVICE_SECURED === 'true' || process.env.ELASTICSEARCH_SERVICE_SECURED === true;
var useSentinel = process.env.REDIS_SENTINEL_SERVICE_HOST ? true : false;

config.serviceName = 'vod-service';

config.redis = {
    host: useSentinel ? process.env.REDIS_SENTINEL_SERVICE_HOST : process.env.REDIS_SERVICE_HOST || 'localhost',
    port: useSentinel ? process.env.REDIS_SENTINEL_SERVICE_PORT : process.env.REDIS_SERVICE_PORT || 6379,
    sentinel: useSentinel
};

config.rest = {
    port: process.env.VOD_SERVER_PORT || 9093
};

config.swaggerPath = {
    protocol: baseSecured ? 'https' : 'http',
    host: process.env.BASE_URL_HOST || localIP,
    port: process.env.BASE_URL_PORT || config.rest.port,
    path: process.env.BASE_URL_PATH || ''
};

config.elasticsearch = {
    client: {
        protocol: elasticSecured ? 'https' : 'http',
        host: process.env.ELASTICSEARCH_SERVICE_HOST || localIP,
        port: process.env.ELASTICSEARCH_SERVICE_PORT || 9200,
        path: process.env.ELASTICSEARCH_SERVICE_PATH || '',
    },
    livenessCheckInterval: 15000
};

config.offlineService = {
    rest: {
        protocol: baseSecured ? 'https' : 'http',
        host: process.env.BASE_URL_HOST || localIP,
        port: process.env.BASE_URL_PORT || config.rest.port,
        path: process.env.BASE_URL_PATH || ''
    },
    socket: {
        protocol: baseSecured ? 'wss' : 'ws',
        host: process.env.BASE_URL_HOST || localIP,
        port: process.env.BASE_URL_PORT || config.rest.port,
        path: process.env.BASE_URL_PATH || '/vod-service'
    }
};

config.keepAlive = {
    noCommunicationTimeout: 100000,
    keepAliveTimeoutMs: 20000
};

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

config.secureMode = false;

config.securitySettings = {
    keyFilePath: './node_modules/express-wrapper/key.pem',
    certificateFilePath: './node_modules/express-wrapper/cert.pem'
};
