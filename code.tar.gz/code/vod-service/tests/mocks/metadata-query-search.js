/*
 * Created by nassi on 23/06/16.
 */

'use strict';

var recordsHistogram = require('./results/recordsHistogram.json');
var recordsAggs = require('./results/recordsAggs.json');
var boundingBox = require('./results/boundingBox.json');
var videoList = require('./results/videoList.json');

class MockMetaDataQuerySearch {

    searchAdvanced() {
        return new Promise((resolve, reject) => {
            return resolve({total: 10, took: 5, hits: []});
        });
    }

    getRecordsAggs(query) {
        return new Promise((resolve, reject) => {
            return resolve(recordsAggs);
        });
    }

    getRecordsHistogram(query) {
        return new Promise((resolve, reject) => {
            return resolve(recordsHistogram);
        });
    }

    getMultiBoundingBox() {
        return new Promise((resolve, reject) => {
            return resolve(boundingBox);
        });
    }

    getVideoList() {
        return new Promise((resolve, reject) => {
            return resolve(videoList);
        });
    }

}

var metaDataSearch = new MockMetaDataQuerySearch();
module.exports = metaDataSearch;
