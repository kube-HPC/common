
module.exports = require('./lib/ElasticClient.js');
