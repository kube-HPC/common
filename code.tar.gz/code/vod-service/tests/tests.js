/*
 * Created by nassi on 17/11/16.
 */

const chai = require('chai');
const expect = chai.expect;
const sinon = require('sinon');
const mockery = require('mockery');
const request = require('request');
const RedisFactory = require('redis-utils').Factory;
const bootstrap = require('../bootstrap');
var clientProxy, config, restUrl, redisClient;
const urlHelper = require('common').UrlHelper;
const OperationTimeout = 20000;

describe('Vod-Service', function () {
    // Enable mockery at the start of your test suite
    before(function (done) {
        mockery.enable({
            useCleanCache: false,
            warnOnReplace: true,
            warnOnUnregistered: false
        });

        mockery.registerSubstitute('elastic-client', process.cwd() + '/tests/mocks/elastic-client');
        mockery.registerSubstitute('./metadata-query-search', process.cwd() + '/tests/mocks/metadata-query-search.js');

        bootstrap.init().then(function (res) {
            config = res;
            redisClient = RedisFactory.getClient(config.redis);
            restUrl = urlHelper.concatUri(config.offlineService.rest);
            clientProxy = require('../lib/index/client-proxy');
            redisClient.flushdb(() => {
                done();
            });
        }).catch((error) => {
            process.exit(1);
        });
    });
    after(function () {
        mockery.deregisterAll();
        mockery.disable(); // Disable Mockery after tests are completed
    });

    describe('REST API', function () {
        const routeSearch = '/vod/search';
        describe(routeSearch, function () {
            it('should return result for regular search with properties', function (done) {
                this.timeout(OperationTimeout);
                request({
                    method: 'POST',
                    uri: restUrl + routeSearch,
                    json: true,
                    body: {}

                }, function (error, response, body) {
                    const record = body.records[0];
                    expect(body).to.have.property('total');
                    expect(body).to.have.property('records');
                    expect(body.records).to.be.an.instanceof(Array);
                    expect(response.statusCode).equal(200);

                    expect(record).to.have.property('recordID');
                    expect(record).to.have.property('segments');
                    expect(record).to.have.property('timerange');
                    expect(record).to.have.property('geoBounds');
                    expect(record).to.have.property('internalData');

                    done();
                });
            });
            it('should return result for geo search with segments', function (done) {
                this.timeout(OperationTimeout);
                request({
                    method: 'POST',
                    uri: restUrl + routeSearch,
                    json: true,
                    body: {
                        'query': {
                            'geoJson': {}
                        }
                    }

                }, function (error, response, body) {
                    const record = body.records[0];
                    expect(body).to.have.property('total');
                    expect(body).to.have.property('records');
                    expect(body.records).to.be.an.instanceof(Array);
                    expect(response.statusCode).equal(200);

                    expect(record).to.have.property('recordID');
                    expect(record).to.have.property('segments');
                    expect(record).to.have.property('timerange');
                    expect(record).to.have.property('geoBounds');
                    expect(record).to.have.property('internalData');

                    done();
                });
            });
            it('should return result for geo search without segments', function (done) {
                this.timeout(OperationTimeout);
                request({
                    method: 'POST',
                    uri: restUrl + routeSearch,
                    json: true,
                    body: {
                        'excludes': ["segments"],
                        'query': {
                            'geoJson': {}
                        }
                    }

                }, function (error, response, body) {
                    const record = body.records[0];
                    expect(body).to.have.property('total');
                    expect(body).to.have.property('records');
                    expect(body.records).to.be.an.instanceof(Array);
                    expect(response.statusCode).equal(200);

                    expect(record).to.have.property('recordID');
                    expect(record).not.to.have.property('segments');
                    expect(record).to.have.property('timerange');
                    expect(record).to.have.property('geoBounds');
                    expect(record).to.have.property('internalData');

                    done();
                });
            });
            it('should return error when searching with invalid query property key', function (done) {
                request({
                    method: 'POST',
                    uri: restUrl + routeSearch,
                    json: true,
                    body: {
                        query: {
                            stam_prop: 'stam_value'
                        }
                    }

                }, function (error, response, body) {
                    expect(body.error.code).to.equal(400);
                    expect(body.error.message).to.equal('stam_prop is not a valid property');
                    expect(response.statusCode).equal(400);
                    expect(response.statusMessage).equal('Bad Request');
                    done();
                });
            });
            it('should return error when searching with invalid query property value', function (done) {
                request({
                    method: 'POST',
                    uri: restUrl + routeSearch,
                    json: true,
                    body: {
                        query: {
                            sensorID: 100
                        }
                    }

                }, function (error, response, body) {
                    expect(body.error.code).to.equal(400);
                    expect(body.error.message).to.equal('instance.query.internalData.sensorID is not of a type(s) string');
                    expect(response.statusCode).equal(400);
                    expect(response.statusMessage).equal('Bad Request');
                    done();
                });
            });
        });

        const routeSearchAdvance = '/vod/search/advanced';
        describe(routeSearchAdvance, function () {
            it('should return result with three properties', function (done) {
                request({
                    method: 'POST',
                    uri: restUrl + routeSearchAdvance,
                    json: true,
                    body: {}

                }, function (error, response, body) {
                    expect(body).to.have.property('hits');
                    expect(body).to.have.property('took');
                    expect(body).to.have.property('total');
                    expect(response.statusCode).equal(200);
                    done();
                });
            });
        });

        const routeList = '/vod/list';
        describe(routeList, function () {
            it('should return result with two properties', function (done) {
                request({
                    method: 'POST',
                    uri: restUrl + routeList,
                    json: true,
                    body: {}

                }, function (error, response, body) {
                    expect(body).to.have.property('total');
                    expect(body).to.have.property('records');
                    expect(body.records).to.be.an.instanceof(Array);
                    expect(response.statusCode).equal(200);
                    done();
                });
            });
            it('should return error when searching with invalid query property key', function (done) {
                request({
                    method: 'POST',
                    uri: restUrl + routeList,
                    json: true,
                    body: {
                        query: {
                            stam_prop: 'stam_value'
                        }
                    }

                }, function (error, response, body) {
                    expect(body.error.code).to.equal(400);
                    expect(body.error.message).to.equal('stam_prop is not a valid property');
                    expect(response.statusCode).equal(400);
                    expect(response.statusMessage).equal('Bad Request');
                    done();
                });
            });
            it('should return error when searching with invalid query property value', function (done) {
                request({
                    method: 'POST',
                    uri: restUrl + routeList,
                    json: true,
                    body: {
                        query: {
                            sensorID: 100
                        }
                    }

                }, function (error, response, body) {
                    expect(body.error.code).to.equal(400);
                    expect(body.error.message).to.equal('instance.query.internalData.sensorID is not of a type(s) string');
                    expect(response.statusCode).equal(400);
                    expect(response.statusMessage).equal('Bad Request');
                    done();
                });
            });
        });
    });
});

