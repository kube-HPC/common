
'use strict';

var args = process.argv[2];
if(args === 'stdout') {
    process.stdout.write('stdout from mock');
}
else {
    process.stderr.write('stderr from mock');
}