/*
 * Created by nassi on 05/10/16.
 */

"use strict";

var chai = require("chai");
var expect = chai.expect;
var sinon = require('sinon');
var mockery = require('mockery');
var SpawnHelper = require('../lib/SpawnHelper');
var ProcessHelper = require('../lib/ProcessHelper');
var errorHandler = require('../lib/errorHandler');
var spawnMock = '/spawn-mock.js';
console.log(`current directory ${__dirname}`);

describe('Common', function () {

    // Enable mockery at the start of your test suite
    before(function (done) {
        mockery.enable({
            useCleanCache: false,
            warnOnReplace: true,
            warnOnUnregistered: false
        });
        done();
    });
    after(function (done) {
        mockery.deregisterAll();
        mockery.disable(); // Disable Mockery after tests are completed
        done();
    });

    describe('SpawnHelper', function () {
        describe('spawn', function () {
            it('should not spawn with ENOENT', function (done) {
                var spawnHelper = new SpawnHelper({path: 'nodex', args: [__dirname + spawnMock]});
                spawnHelper.on('spawn', (process) => {
                    process.on('error', (error) => {
                        expect(error.code).to.equal('ENOENT');
                        done();
                    });
                });
                spawnHelper.spawn();
            });
            it('should spawn stdout', function (done) {
                var spawnHelper = new SpawnHelper({path: 'node', args: [__dirname + spawnMock, 'stdout']});
                spawnHelper.on('stdout', (str) => {
                    expect(str).to.equal('stdout from mock');
                    done();
                });
                spawnHelper.spawn();
            });
            it('should spawn stderr', function (done) {
                var spawnHelper = new SpawnHelper({path: 'node', args: [__dirname + spawnMock, 'stderr']});
                spawnHelper.on('stderr', (str) => {
                    expect(str).to.equal('stderr from mock');
                    done();
                });
                spawnHelper.spawn();
            });
        });
        describe('respawn', function () {
            it('should respawn three times', function (done) {
                this.timeout(20000);
                var spawnHelper = new SpawnHelper({path: 'node', args: [__dirname + spawnMock]});
                spawnHelper.on('respawn', (error, data) => {
                    if (data && data.attempt === 3) {
                        done();
                    }
                    else {
                        spawnHelper.respawn();
                    }
                });
                spawnHelper.spawn();
                spawnHelper.respawn();
            });
            it('should respawn until error', function (done) {
                this.timeout(20000);
                var spawnHelper = new SpawnHelper({path: 'node', args: [__dirname + spawnMock]});
                spawnHelper.on('respawn', (error, data) => {
                    if (error) {
                        done();
                    }
                    else {
                        spawnHelper.respawn();
                    }
                });
                spawnHelper.spawn();
                spawnHelper.respawn();
            });
            it('should respawn with custom backoff', function (done) {
                var spawnHelper = new SpawnHelper({
                    path: 'node',
                    args: [__dirname + spawnMock],
                    backoff: {
                        strategy: 'fixed',
                        delay: 200,
                        maxAttempts: 3
                    }
                });
                spawnHelper.on('respawn', (error, data) => {
                    if (data.strategy === 'fixed') {
                        done();
                    }
                });
                spawnHelper.spawn();
                spawnHelper.respawn();
            });
        });
    });

    describe('ProcessHelper', function () {
        describe('killChilds', function () {
            it('should not spawn with ENOENT', function (done) {
                ProcessHelper.killChilds().then((response) => {
                    done();
                }).catch((error) => {
                    done();
                });
            });
            it('should not spawn with ENOENT', function (done) {
                ProcessHelper.killChilds(process.pid, 'SIGINT').then((response) => {
                    done();
                }).catch((error) => {
                    done();
                });
            });
        });
    });

    xdescribe('ErrorHandler', function () {

        xdescribe('exit', function () {
            it('should catch the event', function (done) {
                errorHandler.on('exit', (code, signal) => {
                    console.log(`exit ${code} ${signal}`);

                });
                done();
                //process.exit(9);
            });
        });
        xdescribe('SIGINT', function () {
            it('should catch the event', function (done) {
                errorHandler.on('SIGINT', (code, signal) => {
                    console.log(`exit ${code} ${signal}`);
                    done();
                });
                process.kill(process.pid, 'SIGINT');
            });
        });
        xdescribe('SIGTERM', function () {
            it('should catch the event', function (done) {
                errorHandler.on('SIGTERM', (code, signal) => {
                    console.log(`SIGTERM ${code} ${signal}`);
                    done();
                });
                process.kill(process.pid, 'SIGTERM');
            });
        });
        describe('uncaughtException', function () {
            it('should catch the event', function (done) {
                errorHandler.on('uncaughtException', (code, signal) => {
                    console.log(`exit ${code} ${signal}`);
                    done();
                });
                no_such_function();
            });
        });
    });
});

