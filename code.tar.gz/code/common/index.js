/*
 * Created by nassi on 23/02/16.
 */

var fs = require('fs');
var path = require('path');

fs.readdirSync(path.join(__dirname, 'lib')).forEach(function (file) {
    var util = file.replace('.js', '');
    try {
        module.exports[util] = require('./lib/' + util);
    }
    catch (e) {
        module.exports[util] = e;
    }
});