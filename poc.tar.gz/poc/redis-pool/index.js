module.exports = require('./lib/connection-pool'); 
