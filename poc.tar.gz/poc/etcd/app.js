const watcher = require('./watcher');
const ttl = require('./ttl');
const dir = require('./dir');
const kv = require('./kv');
watcher.start();
ttl.start();
dir.start();
kv.start();

const test = require('./test');
test.start();

setTimeout(() => {
    // watcher.stop();
    // ttl.stop();
    // dir.stop();
    // kv.stop();
}, 15000);



// setInterval(() => {
//     console.log('');
// }, 15000)