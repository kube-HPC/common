var Etcd = require('node-etcd');
var etcd = new Etcd();

class Test {
    start() {
        etcd.rmdir("/video_1", {recursive: true}, (res, resp) => {
        });
        etcd.mkdir("video_1", () => {
            etcd.mkdir("viewers", () => {
                for (let i = 0; i < 100; i++) {
                    //etcd.set(`video_1/viewers/viewer-${i}`, JSON.stringify({ viewer: { id: i } }));
                    etcd.del(`video_1/viewers/viewer-${i}`);
                }
            });
        });
    }
}

module.exports = new Test();