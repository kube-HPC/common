
const util = require('util');
var Etcd = require('node-etcd');
var etcd = new Etcd('http://127.0.0.1:4001');

class Test {
    start() {
        etcd.mkdir("directory", () => {
            etcd.set("directory/key_1", "val_1");
            etcd.set("directory/key_2", "val_2");
        });
    }

    stop(){
        etcd.rmdir("directory", { recursive: true }, this.callback);
    }

    callback2(err, res) {
        console.log("Error: ", err);
        console.log("Return: ", res);
    }

    callback(res, head) {
        console.log(util.inspect(res, true, 10));
    }
}

module.exports = new Test();