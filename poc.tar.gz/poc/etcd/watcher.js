
const util = require('util');
var Etcd = require('node-etcd');
var etcd = new Etcd('http://127.0.0.1:4001');

class Test {
    start() {
        
        const watcher1 = etcd.watcher("watcher_test");
        watcher1.on("change", this.callback); // Triggers on all changes 
        watcher1.on("set", this.callback);    // Triggers on specific changes (set ops) 
        // watcher1.on("delete", this.callback); // Triggers on delete. 
        // watcher1.on("error", this.callback);
        etcd.set("watcher_test", "val_1");

        // const watcher2 = etcd.watcher("directory/");
        // watcher2.on("change", this.callback); // Triggers on all changes 
        // watcher2.on("set", this.callback);    // Triggers on specific changes (set ops) 
        // watcher2.on("delete", this.callback); // Triggers on delete. 
        // watcher2.on("error", this.callback);
        // etcd.set("directory/key_3", "val_1");
    }

    stop() {
        etcd.del("watcher_test");
    }

    callback2(err, res) {
        console.log("Error: ", err);
        console.log("Return: ", res);
    }

    callback(res, head) {
        console.log(util.inspect(res, true, 10));
    }
}

module.exports = new Test();