
const util = require('util');
var Etcd = require('node-etcd');
var etcd = new Etcd('http://127.0.0.1:4001');

class Test {

    start() {
        etcd.set("test_ttl_key", "test_ttl_value", { ttl: 5 }, this.callback2);
    }

     stop(){
       etcd.del("test_ttl_key");
    }

    callback2(err, res) {
        //console.log("Error: ", err);
        console.log("Return: ", res);
    }

    callback(res, head, val) {
        console.log(util.inspect(res, true, 10));
    }
}

module.exports = new Test();