
const util = require('util');
var Etcd = require('node-etcd');
var etcd = new Etcd('http://127.0.0.1:4001');

class Test {
    start() {
        etcd.set("key_1", "val_1");
        etcd.set("key_2", "val_2");
    }

    stop() {
        etcd.del("key_1", "val_1");
        etcd.del("key_2", "val_2");
    }

    callback2(err, res) {
        console.log("Error: ", err);
        console.log("Return: ", res);
    }

    callback(res, head) {
        console.log(util.inspect(res, true, 10));
    }
}

module.exports = new Test();