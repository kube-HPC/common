var rethink = require('rethinkdb');
var customers = require('./data/customers.json');

rethink.connect({
    host: 'localhost',
    port: 28015,
    db: 'music'
}).then(function (conn) {
    let counter = 0;
    console.time('artists');
    customers.forEach((a) => {
        rethink.table('artists').insert(a).run(conn, function (err, res) {
            counter++;
        });
    });
    while (true) {
        if (counter === customers.length) {
            console.timeEnd('artists');
            break;
        }
    }
}).error(function (error) {
    console.error(error);
});