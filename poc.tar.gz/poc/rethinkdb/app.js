var rethink = require('rethinkdb');
var rethinks = require('./imo');

rethink.connect({
    host: 'localhost',
    port: 28015,
    db: 'music'
}).then(function (conn) {
    rethink.dbCreate('music').run(conn, function (err, res) {
        console.log(res);

        rethink.tableCreate('artists').run(conn, function (err, res) {
            console.log(res);
        });
        rethink.tableCreate('invoices').run(conn, function (err, res) {
            console.log(res);
        });
    });

    rethink.dbDrop('music').run(conn, function (err, res) {
        console.log(res);
    });
}).error(function (error) {
    console.error(error);
});