var consul = require('consul')();

consul.kv.set('hello', 'world', function (err, result) {
    if (err) throw err;
});

consul.catalog.datacenters(function (err, result) {
    if (err) throw err;
});

consul.agent.service.register({
    name: 'my-test-service',
    address: '128.88.99.55',
    port: 9020
}, function (err) {
    if (err) throw err;
});

consul.agent.service.list(function (err, result) {
    if (err) throw err;
});