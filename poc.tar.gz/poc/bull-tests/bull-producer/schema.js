module.exports = {
    "name": "options",
    "type": "object",
    "properties": {
        "job": {
            "type": "object",
            "properties": {
                "type": {
                    "type": "string",
                    "required": true
                },
                "waitingTimeout": {
                    "type": "integer"
                },
                "resolveOnStart": {
                    "type": "boolean"
                },
                "resolveOnComplete": {
                    "type": "boolean"
                }
            }
        },
        "queue": {
            "type": "object",
            "properties": {
                "priority": {
                    "type": "integer"
                },
                "delay": {
                    "type": "integer"
                },
                "timeout": {
                    "type": "integer"
                },
                "attempts": {
                    "type": "integer"
                },
                "removeOnComplete": {
                    "type": "boolean"
                },
                "removeOnFail": {
                    "type": "boolean"
                }
            }
        },
        "setting": {
            "type": "object",
            "properties": {
                "prefix": {
                    "type": "string",
                    "default": 'queue'
                }
            }
        }
    }
}