const EventEmitter = require('events');
const Queue = require('bull');
const validate = require('djsv');
const schema = require('./schema');

// will be a singleton
class Producer extends EventEmitter {

    constructor() {
        super();
        this._jobMap = new Map();
    }

    createJob(options) {
        return new Promise((resolve, reject) => {
            options = options || {};
            const res = validate(options, schema);
            if (!res.valid) {
                return reject(new Error(res.errors[0].stack));
            }
            const queue = new Queue(options.job.type, options.setting);
            queue.on('global:waiting', (jobs, type) => {
                console.log('global:waiting') // TODO
            }).on('global:active', (jobID, jobPromise) => {
                console.log('active')
                // use setImmediate because global:active event is fired 
                // before queue.add has been resolved, and the job id is required here (hook?)
                setImmediate(() => {
                    const job = this._jobMap.get(jobID);
                    if (job && job.options.resolveOnStart) {
                        clearTimeout(job.timeout);
                        this._jobMap.delete(jobID);
                        job.resolve(jobID);
                    }
                    this.emit('job-active', jobID, jobPromise);
                });
            }).on('global:failed', (jobID, err) => {
                const job = this._jobMap.get(jobID);
                if (job) {
                    clearTimeout(job.timeout);
                    this._jobMap.delete(jobID);
                    job.reject(err);
                }
                this.emit('job-failed', jobID, err);
            }).on('global:completed', (jobID, result) => {
                const job = this._jobMap.get(jobID);
                if (job && job.options.resolveOnComplete) {
                    clearTimeout(job.timeout);
                    this._jobMap.delete(jobID);
                    job.resolve(jobID);
                }
                this.emit('job-completed', jobID, result);
            }).on('global:error', (error) => {
                console.error(error.message);
            });;
            queue.add(options.job.data, options.queue).then((job) => {
                console.log('active')
                if (options.job.waitingTimeout > 0) {
                    const timeout = setTimeout(() => {
                        job.discard();
                        job.remove();
                        this._jobMap.delete(job.id);
                        return reject(new Error(`job-waiting-timeout (id: ${job.id})`));
                    }, options.job.waitingTimeout);
                    this._jobMap.set(job.id, { timeout, resolve, reject, options: options.job });
                }
                else {
                    return resolve(job.id);
                }
            }).catch((error) => {
                return reject(error);
            });
        })
    }
}

const options = {
    job: {
        resolveOnStart: false,
        resolveOnComplete: true,
        type: 'test-job',
        data: { action: 'bla' },
        waitingTimeout: 5000,
    },
    queue: {
        priority: 1,
        delay: 1000,
        timeout: 5000,
        attempts: 3,
        removeOnComplete: true,
        removeOnFail: false
    },
    setting: {
        redis: {
            port: 6379,
            host: 'localhost',
        },
        prefix: 'sf-queue'
    }
}

const producer = new Producer();
producer.on('job-active', (jobID, jobPromise) => {
    console.log(`job-active: ${jobID}, ${jobPromise}`);
}).on('job-failed', (jobID, err) => {
    console.log(`job-failed: ${jobID}, ${err}`);
}).on('job-completed', (jobID, result) => {
    console.log(`job-completed: ${jobID}, ${result}`);
});

producer.createJob(options).then((jobID) => {
    console.log(`job started successfully ${jobID}`)
}).catch((error) => {
    console.error(error.message);
});




