const Queue = require('bull');
const redis = require('./redis');

var opts = {
    createClient: function (type) {
        switch (type) {
            case 'client':
                return redis.client;
            case 'subscriber':
                return redis.subscriber;
            default:
                return redis.redis();
        }
    }
}

let options = {
    priority: 1,
    //delay: 1000,
    attempts: 0,
    //lifo: false,
    timeout: 10000,
    removeOnComplete: false,
    removeOnFail: false
}

const RedisOpts = {
    port: 6379,
    host: 'localhost',
}
const AdvancedSettings = {
    lockDuration: 30000,      // Key expiration time for job locks.
    stalledInterval: 30000,   // How often check for stalled jobs (use 0 for never checking).
    maxStalledCount: 0,      // Max amount of times a stalled job will be re-processed.
    guardInterval: 5000,     // Poll interval for delayed jobs and added jobs.s
    retryProcessDelay: 5000  // delay before processing next job in case of internal error.
}

const QueueOpts = {
    redis: RedisOpts,
    prefix: 'bull',
    settings: AdvancedSettings
}

const queue = new Queue('test-job', QueueOpts);

async function start() {
    const job = await queue.add({ image: 'image1.tiff' }, options);
}

queue.on('global:completed', function (job, result) {
    console.log('global:completed');
}).on('global:waiting', function (jobs, type) {
    console.log('global:waiting');
}).on('global:error', function (error) {
    console.log('global:error');
}).on('global:active', function (job, jobPromise) {
    console.log('global:active');
}).on('global:stalled', function (job) {
    console.log('global:stalled');
}).on('global:progress', function (job, progress) {
    console.log(`global:progress ${progress}`);
}).on('global:failed', function (job, err) {
    console.log(`global:failed ${err}`);
}).on('global:paused', function () {
    console.log('global:paused');
}).on('global:resumed', function (job) {
    console.log('global:resumed');
}).on('global:cleaned', function (jobs, type) {
    console.log('global:cleaned');
});

start();


