const Queue = require('bull');

const options = {
    timeout: 10000,
    waitingTimeout: 10000
}

const jobMap = new Map();

const createJob = (options) => {
    return new Promise((resolve, reject) => {
        const queue = new Queue(options.jobType);
        queue.on('global:waiting', function (jobs, type) {

        }).on('global:error', function (error) {

        }).on('global:active', function (job, jobPromise) {

        }).on('global:failed', function (job, err) {
        });

        queue.add({ data: 'bla' }, options).then((job) => {
            if (options.timeout > 0) {
                const timeout = setTimeout(() => {
                    return reject(new Error('job-waiting-timeout'));
                }, options.timeout);
                jobMap.set(job, { timeout, resolve, reject });
            }
            else {
                return resolve(job);
            }
        }).catch((error) => {
            return reject(error);
        });
    })
}

const createJob = (options) => {

}

createJob(options)