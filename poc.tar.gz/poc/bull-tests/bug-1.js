// Producer
const Queue = require('bull');

// init Queue
const queue = new Queue('test-job');

// register for global:waiting
queue.on('global:waiting', function (job) {
    console.log('global:waiting');
});

// init simple options
let options = {
    priority: 1,
    removeOnComplete: false,
    removeOnFail: false
}

// create new job
queue.add({ image: 'image1.tiff' }, options);

// The event 'global:waiting' is not fired