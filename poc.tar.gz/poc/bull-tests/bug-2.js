// Producer
const Queue = require('bull');
const queue = new Queue('test-job');

queue.on('global:stalled', function (job) {
    console.log('global:stalled');
});

let options = { priority: 1, removeOnComplete: false, removeOnFail: false }
queue.add({ image: 'image1.tiff' }, options);

// Consumer 1
const Queue = require('bull');
const queue = new Queue('test-job');

// get job and then kill process
queue.process(function (job, done) {
    process.exit(0);
});

// Consumer 2
const Queue = require('bull');
const queue = new Queue('test-job');

queue.process(function (job, done) {
    job.progress(20);

    setTimeout(() => {
        done(null, { msg: 'bla' });
    }, 2000);
});

queue.on('active', function (job, jobPromise) {
    console.log('active');
}).on('stalled', function (job) {
    console.log('stalled');
}).on('progress', function (job, progress) {
    console.log('progress');
});

// Notes:
// 1) Consumer 2 fire events: stalled -> active -> progress
// 2) The Producer don't get the stalled event, how it can get notification on process crash?
// 3) Consumer 2 automatically get the job, can be disabled?
