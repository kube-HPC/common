var Redis = require('ioredis');
// var client = new Redis({
//     sentinels: [{ host: '127.0.0.1', port: 26379 }],
//     name: 'mymaster'
// });

var client = new Redis({ host: '127.0.0.1', port: 6379 });
var subscriber = new Redis({ host: '127.0.0.1', port: 6379 });

module.exports = {
    client,
    subscriber,
    redis: () => new Redis({ host: '127.0.0.1', port: 6379 })
}