const Queue = require('bull');

const RedisOpts = {
    port: 6379,
    host: 'localhost',
}
const AdvancedSettings = {
    lockDuration: 30000,     // Key expiration time for job locks.
    stalledInterval: 30000,  // How often check for stalled jobs (use 0 for never checking).
    maxStalledCount: 0,      // Max amount of times a stalled job will be re-processed.
    guardInterval: 5000,     // Poll interval for delayed jobs and added jobs.
    retryProcessDelay: 5000  // delay before processing next job in case of internal error.
}

const QueueOpts = {
    redis: RedisOpts,
    prefix: 'sf-queue',
    settings: AdvancedSettings
}

const queue = new Queue('test-job', QueueOpts);
let i = 0;

queue.process(function (job, done) {
    console.log('job arrived');
    setTimeout(() => {
        job.progress(i++);
    }, 1000);

    //const result = new Error('ooopss');
    const result = null; //new Error('ooopss');

    setTimeout(() => {
        done(result, { width: 1280, height: 720 });
    }, 5000);
});

queue.on('completed', function (job, result) {
    console.log('completed');
}).on('waiting', function (jobs, type) {
    console.log('waiting');
}).on('error', function (error) {
    console.log('error');
}).on('active', function (job, jobPromise) {
    console.log('active');
}).on('stalled', function (job) {
    console.log('stalled');
}).on('progress', function (job, progress) {
    console.log('progress');
}).on('failed', function (job, err) {
    console.log('failed');
}).on('paused', function () {
    console.log('paused');
}).on('resumed', function (job) {
    console.log('resumed');
}).on('cleaned', function (jobs, type) {
    console.log('cleaned');
});